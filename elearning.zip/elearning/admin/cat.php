<div id="bodyright">

    <?php
    if (isset($_GET['edit_cat'])) {
        echo edit_cat();
    } else {
    ?>
        <h3>View All Kategori</h3>
        <div id="add">
            <details>
                <summary>Tambah Kategori</summary>
                <form method="post" enctype="multipart/form-data">
                    <input type="text" name="cat_name" placeholder="Nama Kategori">
                    <input type="text" name="cat_icon" placeholder="Icon Kategori">
                    <center><button name="add_cat">Tambah Kategori</button></center>
                </form>
            </details>
            <table cellspacing="0">
                <tr>
                    <th>No</th>
                    <th>Kategori</th>
                    <th>Edit</th>
                    <th>Action</th>
                </tr>
                <?php echo view_cat(); ?>
            </table>
        </div>
</div>
<?php
echo add_cat(); }
?>