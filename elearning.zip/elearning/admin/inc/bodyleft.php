<div id="bodyleft">
    <h3>Manajemen Kategori</h3>
    <ul>
        <li><a href="index.php"><i class="fas fa-home fa-lg"></i> Dashboard</a></li>
        <li><a href="index.php?cat"><i class="far fa-folder-open fa-lg"></i> Lihat Kategori</a></li>
        <li><a href="index.php?sub_cat"><i class="fas fa-clone fa-lg"></i>Lihat Sub Kategori</a></li>
        <li><a href="index.php?lang"><i class="fas fa-language fa-lg"></i>Lihat Bahasa</a></li>
    </ul>
    <h3>Manajemen Kursus</h3>
    <ul>
        <li><a href="#"><i class="fas fa-toggle-on fa-lg"></i>Aktif</a></li>
        <li><a href="#">Pending</a></li>
        <li><a href="#">Belum diunggah</a></li>
        <li><a href="#">Pencarian Kursus</a></li>
    </ul>
    <h3>Manajemen User</h3>
    <ul>
        <li><a href="#"><i class="fas fa-child fa-lg"></i>Peserta</a></li>
        <li><a href="#"><i class="fas fa-chalkboard-teacher fa-lg"></i>Kakak Mentor</a></li>
        <li><a href="#">Pencarian User</a></li>
    </ul>
    <h3>Manajemen Pembayaran</h3>
    <ul>
        <li><a href="#">Pembayaran ke Mentor</a></li>
        <li><a href="#">Pembayaran Selesai</a></li>
        <li><a href="#">Pencarian Pembayaran</a></li>
    </ul>
    <h3>Manajemen Halaman</h3>
    <ul>
        <li><a href="index.php?terms">Terms Condition</a></li>
        <li><a href="index.php?about">Profil</a></li>
        <li><a href="index.php?contact">Kontak</a></li>
        <li><a href="index.php?faqs">FAQs</a></li>
        <li><a href="#">Edit Slider</a></li>
    </ul>   
</div>

<?php
    if(isset($_GET['cat'])){
        include ("cat.php");
    }
    if(isset($_GET['sub_cat'])){
        include ("sub_cat.php");
    }
    if(isset($_GET['lang'])){
        include ("lang.php");
    }
    if(isset($_GET['terms'])){
        include ("terms.php");
    }
    if(isset($_GET['contact'])){
        include ("contact.php");
    }
    if(isset($_GET['faqs'])){
        include ("faqs.php");
    }
    if(isset($_GET['about'])){
        include ("about.php");
    }
?>