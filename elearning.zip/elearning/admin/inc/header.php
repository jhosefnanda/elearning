<?php
    include ("inc/function.php");
?>
<div id="header">
    <div id="logo">
        <h2><a href="index.php">Learning</a></h2>
    </div>
    <div id="title">
        <h2>Admin Panel</h2>
    </div>
    <div id="link">
        <h3><a href="#">Logout</a></h3>
    </div>
</div>