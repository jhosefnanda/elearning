<?php
    if(!isset($_GET['about']) && !isset($_GET['faqs']) && !isset($_GET['contact']) && !isset($_GET['terms']) && !isset($_GET['lang']) && !isset($_GET['cat']) && !isset($_GET['sub_cat'])){
?>
<div id="bodyright">
    <h3>Overview</h3>
</div>
<?php
    }
?>