<?php
    $con = new PDO("mysql:host=Localhost;dbname=db_elearning","root","");
?>