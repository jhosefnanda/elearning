<?php

function add_lang()
{
    include("inc/db.php");
    if (isset($_POST['add_lang'])) {
        $lang_name = $_POST['lang_name'];

        $check = $con->prepare("select * from lang where lang_name='$lang_name'");
        $check->setFetchMode(PDO::FETCH_ASSOC);
        $check->execute();
        $count = $check->rowCount();

        if ($count == 1) {
            echo "<script>alert('Language already Added !')</script>";
            echo "<script>window.open('index.php?lang','_self')</script>";
        } else {
            $add_lang = $con->prepare("insert into tb_lang values ('','$lang_name','','')");

            if ($add_lang->execute()) {
                echo "<script>alert('Berhasil')</script>";
                echo "<script>window.open('index.php?lang','_self')</script>";
            } else {
                echo "<script>alert('Gagal')</script>";
                echo "<script>window.open('index.php?lang','_self')</script>";
            }
        }
    }
}

function view_lang()
{
    include("inc/db.php");

    $get_lang = $con->prepare("SELECT * FROM tb_lang");
    $get_lang->setFetchMode(PDO::FETCH_ASSOC);
    $get_lang->execute();

    $i = 1;

    while ($row = $get_lang->fetch()) :
        echo "<tr>
                    <td>" . $i++ . "</td>
                    <td>" . $row['lang_name'] . "</td>
                    <td><a title='Edit Language' href='index.php?lang&edit_lang=" . $row['id'] . "'><i class='fas fa-edit fa-lg'></i></a></td>
                    <td><a title='Delete Language' style='color: red' href='index.php?lang&del_lang=" . $row['id'] . "'><i class='fas fa-trash fa-lg'></i></a></td>
                </tr>";
    endwhile;
    if (isset($_GET['del_lang'])) {
        $id = $_GET['del_lang'];
        $del = $con->prepare("delete from tb_lang where id='$id'");
        if ($del->execute()) {
            echo "<script>alert('Berhasil dihapus')</script>";
            echo "<script>window.open('index.php?lang','_self')</script>";
        } else {
            echo "<script>alert('Gagal dihapus')</script>";
            echo "<script>window.open('index.php?lang','_self')</script>";
        }
    }
}

function edit_lang()
{
    include("inc/db.php");
    if (isset($_GET['edit_lang'])) {
        // Mengambil Nama Kategori yang akan di edit berdasarkan ID
        $id = $_GET['edit_lang'];

        $get_lang = $con->prepare("SELECT * FROM tb_lang WHERE id = '$id'");
        $get_lang->setFetchMode(PDO::FETCH_ASSOC);
        $get_lang->execute();

        $row = $get_lang->fetch();
        // Selesai mengambil nama kategori

        // Menampilkan nama kategori yang akan di update di dalam form input
        echo "
        <h3>Edit Language</h3>
        <form id='edit_form' method='post' enctype='multipart/form-data'>
            <input type='text' name='lang_name' value=" . $row['lang_name'] . ">
            <center><button name='edit_lang'>Edit Language</button></center>
        </form>
        ";

        if (isset($_POST['edit_lang'])) {
            $lang_name = $_POST['lang_name'];

            $check = $con->prepare("select * from tb_kategori where kategori='$lang_name'");
            $check->setFetchMode(PDO::FETCH_ASSOC);
            $check->execute();
            $count = $check->rowCount();

            if ($count == 1) {
                echo "<script>alert('Language sudah ada !')</script>";
                echo "<script>window.open('index.php?lang','_self')</script>";
            } else {

                $update_lang = $con->prepare("update tb_lang set lang_name='$lang_name' WHERE id='$id'");

                if ($update_lang->execute()) {
                    echo "<script>alert('Berhasil di edit')</script>";
                    echo "<script>window.open('index.php?lang','_self')</script>";
                } else {
                    echo "<script>alert('Gagal')</script>";
                    echo "<script>window.open('index.php?lang','_self')</script>";
                }
            }
        }
    }
}


function add_cat()
{
    include("inc/db.php");
    if (isset($_POST['add_cat'])) {
        $cat_name = $_POST['cat_name'];

        $check = $con->prepare("select * from tb_kategori where kategori='$cat_name'");
        $check->setFetchMode(PDO::FETCH_ASSOC);
        $check->execute();
        $count = $check->rowCount();

        if ($count == 1) {
            echo "<script>alert('Kategori sudah ada !')</script>";
            echo "<script>window.open('index.php?cat','_self')</script>";
        } else {
            $add_cat = $con->prepare("insert into tb_kategori values ('','$cat_name','','')");

            if ($add_cat->execute()) {
                echo "<script>alert('Berhasil')</script>";
                echo "<script>window.open('index.php?cat','_self')</script>";
            } else {
                echo "<script>alert('Gagal')</script>";
                echo "<script>window.open('index.php?cat','_self')</script>";
            }
        }
    }
}

function edit_cat()
{
    include("inc/db.php");
    if (isset($_GET['edit_cat'])) {
        // Mengambil Nama Kategori yang akan di edit berdasarkan ID
        $id = $_GET['edit_cat'];

        $get_cat = $con->prepare("SELECT * FROM tb_kategori WHERE id = '$id'");
        $get_cat->setFetchMode(PDO::FETCH_ASSOC);
        $get_cat->execute();

        $row = $get_cat->fetch();
        // Selesai mengambil nama kategori

        // Menampilkan nama kategori yang akan di update di dalam form input
        echo "
        <h3>Edit Kategori</h3>
        <form id='edit_form' method='post' enctype='multipart/form-data'>
            <input type='text' name='cat_name' value=" . $row['kategori'] . ">
            <input type='text' name='cat_icon'>
            <center><button name='edit_cat'>Edit Kategori</button></center>
        </form>
        ";

        if (isset($_POST['edit_cat'])) {
            $cat_name = $_POST['cat_name'];

            $check = $con->prepare("select * from tb_kategori where kategori='$cat_name'");
            $check->setFetchMode(PDO::FETCH_ASSOC);
            $check->execute();
            $count = $check->rowCount();

            if ($count == 1) {
                echo "<script>alert('Kategori sudah ada !')</script>";
                echo "<script>window.open('index.php?cat','_self')</script>";
            } else {

                $update_cat = $con->prepare("update tb_kategori set kategori='$cat_name' WHERE id='$id'");

                if ($update_cat->execute()) {
                    echo "<script>alert('Berhasil di edit')</script>";
                    echo "<script>window.open('index.php?cat','_self')</script>";
                } else {
                    echo "<script>alert('Gagal')</script>";
                    echo "<script>window.open('index.php?cat','_self')</script>";
                }
            }
        }
    }
}

function view_cat()
{
    include("inc/db.php");

    $get_cat = $con->prepare("SELECT * FROM tb_kategori");
    $get_cat->setFetchMode(PDO::FETCH_ASSOC);
    $get_cat->execute();

    $i = 1;

    while ($row = $get_cat->fetch()) :
        echo "<tr>
                    <td>" . $i++ . "</td>
                    <td>" . $row['kategori'] . "</td>
                    <td><a href='index.php?cat&edit_cat=" . $row['id'] . "'>Edit</a></td>
                    <td><a href='index.php?cat&del_cat=" . $row['id'] . "'>Hapus</a></td>
                </tr>";
    endwhile;
    if (isset($_GET['del_cat'])) {
        $id = $_GET['del_cat'];
        $del = $con->prepare("delete from tb_kategori where id='$id'");
        if ($del->execute()) {
            echo "<script>alert('Berhasil dihapus')</script>";
            echo "<script>window.open('index.php?cat','_self')</script>";
        } else {
            echo "<script>alert('Gagal dihapus')</script>";
            echo "<script>window.open('index.php?cat','_self')</script>";
        }
    }
}

function select_cat()
{
    include("inc/db.php");

    $get_cat = $con->prepare("SELECT * FROM tb_kategori");
    $get_cat->setFetchMode(PDO::FETCH_ASSOC);
    $get_cat->execute();

    while ($row = $get_cat->fetch()) :
        echo "<option value='" . $row['id'] . "'>" . $row['kategori'] . "</option>";
    endwhile;
}

function add_sub_cat()
{
    include("inc/db.php");
    if (isset($_POST['add_sub_cat'])) {
        $sub_cat_name = $_POST['sub_cat_name'];
        $cat_id = $_POST['cat_id'];
        $check = $con->prepare("select * from tb_sub_kategori where sub_kategori='$sub_cat_name'");
        $check->setFetchMode(PDO::FETCH_ASSOC);
        $check->execute();
        $count = $check->rowCount();

        if ($count == 1) {
            echo "<script>alert('Sub Kategori sudah ada !')</script>";
            echo "<script>window.open('index.php?sub_cat','_self')</script>";
        } else {
            $add_cat = $con->prepare("insert into tb_sub_kategori values ('','$sub_cat_name','$cat_id','','')");

            if ($add_cat->execute()) {
                echo "<script>alert('Berhasil')</script>";
                echo "<script>window.open('index.php?sub_cat','_self')</script>";
            } else {
                echo "<script>alert('Gagal')</script>";
                echo "<script>window.open('index.php?sub_cat','_self')</script>";
            }
        }
    }
}

function view_sub_cat()
{
    include("inc/db.php");

    $get_sub_cat = $con->prepare("SELECT * FROM tb_sub_kategori");
    $get_sub_cat->setFetchMode(PDO::FETCH_ASSOC);
    $get_sub_cat->execute();

    $i = 1;

    while ($row = $get_sub_cat->fetch()) :
        $cat_id = $row['kategori_id'];
        $get_cat_name = $con->prepare("SELECT * from tb_kategori WHERE id='$cat_id'");
        $get_cat_name->setFetchMode(PDO::FETCH_ASSOC);
        $get_cat_name->execute();

        $row_cat = $get_cat_name->fetch();
        echo "<tr>
                    <td>" . $i++ . "</td>
                    <td>" . $row['sub_kategori'] . "</td>
                    <td>" . $row_cat['kategori'] . "</td>
                    <td><a href='index.php?sub_cat&edit_sub_cat=" . $row['id'] . "'>Edit</a></td>
                    <td><a href='index.php?sub_cat&del_sub_cat=" . $row['id'] . "'>Hapus</a></td>
                </tr>";
    endwhile;
    if (isset($_GET['del_sub_cat'])) {
        $id = $_GET['del_sub_cat'];
        $del = $con->prepare("delete from tb_sub_kategori where id='$id'");
        if ($del->execute()) {
            echo "<script>alert('Berhasil dihapus')</script>";
            echo "<script>window.open('index.php?sub_cat','_self')</script>";
        } else {
            echo "<script>alert('Gagal dihapus')</script>";
            echo "<script>window.open('index.php?sub_cat','_self')</script>";
        }
    }
}

function edit_sub_cat()
{
    include("inc/db.php");
    if (isset($_GET['edit_sub_cat'])) {
        $id = $_GET['edit_sub_cat'];

        $get_sub_cat = $con->prepare("SELECT * FROM tb_sub_kategori WHERE id = '$id'");
        $get_sub_cat->setFetchMode(PDO::FETCH_ASSOC);
        $get_sub_cat->execute();

        $row = $get_sub_cat->fetch();

        // Mengambil Nama Kategori yang akan di edit berdasarkan ID
        $cat_id = $row['kategori_id'];
        $get_cat = $con->prepare("SELECT * FROM tb_kategori WHERE id = '$cat_id'");
        $get_cat->setFetchMode(PDO::FETCH_ASSOC);
        $get_cat->execute();

        $row_cat = $get_cat->fetch();
        // Selesai mengambil nama kategori

        // Menampilkan nama kategori yang akan di update di dalam form input
        echo "
        <h3>Edit Sub Kategori</h3>
        <form id='edit_form' method='post' enctype='multipart/form-data'>
            <select name='cat_id'>
                        <option value='" . $row_cat['id'] . "'>" . $row_cat['kategori'] . "</option>";
        echo select_cat();
        echo "</select>
            <input type='text' name='sub_cat_name' value=" . $row['sub_kategori'] . ">
            <center><button name='edit_sub_cat'>Edit Sub Kategori</button></center>
        </form>
        ";

        if (isset($_POST['edit_sub_cat'])) {
            $cat_name = $_POST['sub_cat_name'];

            // Mengambil ID Kategori
            $cat_id = $_POST['cat_id'];
            $check = $con->prepare("select * from tb_sub_kategori where sub_kategori='$cat_name'");
            $check->setFetchMode(PDO::FETCH_ASSOC);
            $check->execute();
            $count = $check->rowCount();

            if ($count == 1) {
                echo "<script>alert('Sub Kategori sudah ada !')</script>";
                echo "<script>window.open('index.php?sub_cat','_self')</script>";
            } else {

                $update_cat = $con->prepare("update tb_sub_kategori set sub_kategori='$cat_name',kategori_id='$cat_id' WHERE id='$id'");

                if ($update_cat->execute()) {
                    echo "<script>alert('Berhasil di edit')</script>";
                    echo "<script>window.open('index.php?sub_cat','_self')</script>";
                } else {
                    echo "<script>alert('Gagal')</script>";
                    echo "<script>window.open('index.php?sub_cat','_self')</script>";
                }
            }
        }
    }
}

function view_term()
{
    include("inc/db.php");
    $get_term = $con->prepare("SELECT * from tb_term");
    $get_term->setFetchMode(PDO::FETCH_ASSOC);
    $get_term->execute();
    $i = 1;
    while ($row = $get_term->fetch()) :
        echo "<tr>
                    <td>" . $i++ . "</td>
                    <td>" . $row['term'] . "</td>
                    <td>" . $row['for_whome'] . "</td>
                    <td><a href='index.php?terms&edit_term=" . $row['id'] . "'>Edit</a></td>
                    <td><a href='index.php?terms&del_term=" . $row['id'] . "'>Hapus</a></td>
                </tr>";
    endwhile;

    if (isset($_GET['del_term'])) {
        $id = $_GET['del_term'];
        $del = $con->prepare("delete from tb_term where id='$id'");
        if ($del->execute()) {
            echo "<script>alert('Berhasil dihapus')</script>";
            echo "<script>window.open('index.php?terms','_self')</script>";
        } else {
            echo "<script>alert('Gagal dihapus')</script>";
            echo "<script>window.open('index.php?terms','_self')</script>";
        }
    }
}

function add_term()
{
    include("inc/db.php");
    if (isset($_POST['add_term'])) {
        $term = $_POST['term'];
        $for_whome = $_POST['for_whome'];

        $check = $con->prepare("select * from tb_term where term='$term'");
        $check->setFetchMode(PDO::FETCH_ASSOC);
        $check->execute();
        $count = $check->rowCount();

        if ($count == 1) {
            echo "<script>alert('Term sudah ada !')</script>";
            echo "<script>window.open('index.php?term','_self')</script>";
        } else {
            $add_term = $con->prepare("insert into tb_term values ('','$term','$for_whome','','')");

            if ($add_term->execute()) {
                echo "<script>alert('Berhasil')</script>";
                echo "<script>window.open('index.php?terms','_self')</script>";
            } else {
                echo "<script>alert('Gagal')</script>";
                echo "<script>window.open('index.php?terms','_self')</script>";
            }
        }
    }
}

function edit_term()
{
    include("inc/db.php");
    if (isset($_GET['edit_term'])) {
        // Mengambil Nama Kategori yang akan di edit berdasarkan ID
        $id = $_GET['edit_term'];

        $get_cat = $con->prepare("SELECT * FROM tb_term WHERE id = '$id'");
        $get_cat->setFetchMode(PDO::FETCH_ASSOC);
        $get_cat->execute();

        $row = $get_cat->fetch();
        // Selesai mengambil nama kategori

        // Menampilkan nama kategori yang akan di update di dalam form input
        echo "
        <h3>Edit Term</h3>
        <form id='edit_form' method='post' enctype='multipart/form-data'>
        <select name='for_whome'>
                        <option value='" . $row['for_whome'] . "'>" . $row['for_whome'] . "</option>
                        <option value='student'>Student</option>
                        <option value='teacher'>Teacher</option>
                        ";
        echo "</select>
            <input type='text' name='term' value='" . $row['term'] . "'>
            <center><button name='edit_term'>Edit Term</button></center>
        </form>
        ";

        if (isset($_POST['edit_term'])) {
            $term = $_POST['term'];
            $for_whome = $_POST['for_whome'];

            $check = $con->prepare("select * from tb_term where term='$term'");
            $check->setFetchMode(PDO::FETCH_ASSOC);
            $check->execute();
            $count = $check->rowCount();

            if ($count == 1) {
                echo "<script>alert('Term sudah ada !')</script>";
                echo "<script>window.open('index.php?terms','_self')</script>";
            } else {

                $update_cat = $con->prepare("update tb_term set term='$term',for_whome='$for_whome' WHERE id='$id'");

                if ($update_cat->execute()) {
                    echo "<script>alert('Berhasil di edit')</script>";
                    echo "<script>window.open('index.php?terms','_self')</script>";
                } else {
                    echo "<script>alert('Gagal')</script>";
                    echo "<script>window.open('index.php?terms','_self')</script>";
                }
            }
        }
    }
}

function contact()
{
    include('inc/db.php');

    $get_con = $con->prepare("SELECT * FROM tb_contact");
    $get_con->setFetchMode(PDO::FETCH_ASSOC);
    $get_con->execute();

    $row = $get_con->fetch();

    echo "
    <form method='post' enctype='multipart/form-data'>
            <table>
                <tr>
                    <td>Update Contact Number</td>
                    <td><input type='number' name='phone' value='" . $row['phone'] . "' placeholder='Phone Number'></td>
                </tr>
                <tr>
                    <td>Update Email</td>
                    <td><input type='email' name='email' value='" . $row['email'] . "' placeholder='Email account'></td>
                </tr>
                <tr>
                    <td>Update Address 1</td>
                    <td><input type='text' name='address1' value='" . $row['address1'] . "' placeholder='First address'></td>
                </tr>
                <tr>
                    <td>Update Address 2</td>
                    <td><input type='text' name='address2' value='" . $row['address2'] . "' placeholder='Second Address'></td>
                </tr>
                <tr>
                    <td>https://www.youtube.com/</td>
                    <td><input type='text' name='youtube' value='" . $row['youtube'] . "' placeholder='URL Youtube Channel'></td>
                </tr>
                <tr>
                    <td>https://www.linkedin.com/</td>
                    <td><input type='text' name='linkedin' value='" . $row['linkedin'] . "' placeholder='URL Linkedin Account'></td>
                </tr>
                <tr>
                    <td>https://www.instagram.com/</td>
                    <td><input type='text' name='instagram' value='" . $row['instagram'] . "' placeholder='URL Instagram Account'></td>
                </tr>
                <tr>
                    <td>https://www.facebook.com/</td>
                    <td><input type='text' name='facebook' value='" . $row['facebook'] . "' placeholder='URL Facebook Account'></td>
                </tr>
            </table>
            <center><button name='update_contact'>Update Contact</button></center>
        </form>
    ";

    if (isset($_POST['update_contact'])) {
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'];
        $youtube = $_POST['youtube'];
        $linkedin = $_POST['linkedin'];
        $instagram = $_POST['instagram'];
        $facebook = $_POST['facebook'];

        $update = $con->prepare("update tb_contact set 
                            phone='$phone',
                            email='$email',
                            address1='$address1',
                            address2='$address2',
                            youtube='$youtube',
                            linkedin='$linkedin',
                            instagram='$instagram',
                            facebook='$facebook'
                            ");

        if ($update->execute()) {
            echo "<script>alert('Berhasil')</script>";
            echo "<script>window.open('index.php?contact','_self')</script>";
        } else {
            echo "<script>alert('Gagal')</script>";
            echo "<script>window.open('index.php?contact','_self')</script>";
        }
    }
}

function add_faqs()
{
    include("inc/db.php");
    if (isset($_POST['add_faqs'])) {
        $qsn = $_POST['qsn'];
        $ans = $_POST['ans'];

        $check = $con->prepare("select * from tb_faqs where question='$qsn'");
        $check->setFetchMode(PDO::FETCH_ASSOC);
        $check->execute();
        $count = $check->rowCount();

        if ($count == 1) {
            echo "<script>alert('Question is exist !')</script>";
            echo "<script>window.open('index.php?faqs','_self')</script>";
        } else {
            $add_faqs = $con->prepare("insert into tb_faqs values ('','$qsn','$ans','','')");

            if ($add_faqs->execute()) {
                echo "<script>alert('Berhasil')</script>";
                echo "<script>window.open('index.php?faqs','_self')</script>";
            } else {
                echo "<script>alert('Gagal')</script>";
                echo "<script>window.open('index.php?faqs','_self')</script>";
            }
        }
    }
}

function view_faqs()
{
    include("inc/db.php");
    $get_faqs = $con->prepare("SELECT * from tb_faqs");
    $get_faqs->setFetchMode(PDO::FETCH_ASSOC);
    $get_faqs->execute();

    while ($row = $get_faqs->fetch()) :
        echo "
        <details>
        <summary>" . $row['question'] . "</summary>
        <form method='post' enctype='multipart/form-data'>
            <input type='text' name='qsn' value='" . $row['question'] . "' placeholder='The Question'>
            <input type='hidden' name='id' value='" . $row['id'] . "'>
            <textarea name='ans' placeholder='The Answer here'>" . $row['answer'] . "</textarea>
            <center><button name='update_faqs'>Update FAQs</button></center>
        </form>
        </details></br>";
    endwhile;

    if (isset($_POST['update_faqs'])) {
        $qsn = $_POST['qsn'];
        $ans = $_POST['ans'];
        $id = $_POST['id'];

        $update_faqs = $con->prepare("update tb_faqs set question='$qsn',answer='$ans' WHERE id='$id'");

        if ($update_faqs->execute()) {
            echo "<script>alert('Berhasil')</script>";
            echo "<script>window.open('index.php?faqs','_self')</script>";
        } else {
            echo "<script>alert('Gagal')</script>";
            echo "<script>window.open('index.php?faqs','_self')</script>";
        }
    }
}

function about()
{
    include("inc/db.php");
    $get_about = $con->prepare("SELECT * from tb_about");
    $get_about->setFetchMode(PDO::FETCH_ASSOC);
    $get_about->execute();

    while ($row = $get_about->fetch()) :
        echo "
    <form method='post' enctype='multipart/form-data'>
    <input type='hidden' name='id' value='" . $row['id'] . "'/>
    <textarea name='about'>" . $row['about'] . "</textarea>
    <button name='update_about'>Update</button>
</form>
    ";
    endwhile;

    if (isset($_POST['update_about'])) {
        $about = $_POST['about'];
        $id = $_POST['id'];

        $update_about = $con->prepare("update tb_about set about='$about' WHERE id='$id'");

        if ($update_about->execute()) {
            echo "<script>alert('Berhasil')</script>";
            echo "<script>window.open('index.php?about','_self')</script>";
        } else {
            echo "<script>alert('Gagal')</script>";
            echo "<script>window.open('index.php?about','_self')</script>";
        }
    }
}
