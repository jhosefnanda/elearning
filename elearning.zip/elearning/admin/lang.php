<div id="bodyright">
    <?php
    if (isset($_GET['edit_lang'])) {
        echo edit_lang();
    } else {
    ?>
        <h3>View All Kategori</h3>
        <div id="add">
            <details>
                <summary>Tambah Bahasa</summary>
                <form method="post" enctype="multipart/form-data">
                    <input type="text" name="lang_name" placeholder="Add Language Here">
                    <center><button name="add_lang">Tambah Bahasa</button></center>
                </form>
            </details>
            <table cellspacing="0">
                <tr>
                    <th>No</th>
                    <th>Bahasa</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                <?php echo view_lang(); ?>
            </table>
        </div>
    <?php } ?>
</div>
<?php
echo add_lang();
?>