<div id="bodyright">
    <?php
    if (isset($_GET['edit_sub_cat'])) {
        echo edit_sub_cat();
    } else {
    ?>
        <h3>Data Semua Sub Kategori</h3>
        <div id="add">
            <details>
                <summary>Tambah Sub Kategori</summary>
                <form method="post" enctype="multipart/form-data">
                    <select name="cat_id">
                        <option>Pilih Kategori</option>
                        <?php echo select_cat(); ?>
                    </select>
                    <input type="text" name="sub_cat_name" placeholder="Nama Sub Kategori">
                    <center><button name="add_sub_cat">Tambah Sub Kategori</button></center>
                </form>
            </details>
            <table cellspacing="0">
                <tr>
                    <th>No</th>
                    <th>Sub Kategori</th>
                    <th>Kategori</th>
                    <th>Edit</th>
                    <th>Nonaktifkan</th>
                </tr>
                <?php echo view_sub_cat(); ?>
            </table>
        </div>
    <?php } ?>
</div>
<?php
echo add_sub_cat();
?>