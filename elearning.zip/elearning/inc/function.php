<?php
function head_link()
{
    include('inc/db.php');

    $get_link = $con->prepare("select * from tb_contact");
    $get_link->setFetchMode(PDO::FETCH_ASSOC);
    $get_link->execute();
    $row      = $get_link->fetch();

    echo "
    <ul>
    <li><a href='" . $row['facebook'] . "'><i class='fab fa-facebook'></i></a></li>
    <li><a href='" . $row['youtube'] . "'><i class='fab fa-youtube'></i></a></li>
    <li><a href='" . $row['instagram'] . "'><i class='fab fa-instagram'></i></a></li>
</ul>
    ";
}
// <li><a href='".$row['twitter']."'><i class='fab fa-twitter'></i></a></li>

function categoryOnHeader()
{
    include('inc/db.php');

    $get_menu = $con->prepare("select * from tb_kategori");
    $get_menu->setFetchMode(PDO::FETCH_ASSOC);
    $get_menu->execute();

    while ($row = $get_menu->fetch()) :
        echo "
        <li><a href=''><i class='fas fa-code'></i>" . $row['kategori'] . "</a></li>
        ";
    endwhile;
}

function categoryOnBody()
{
    include('inc/db.php');

    $get_menu = $con->prepare("select * from tb_kategori");
    $get_menu->setFetchMode(PDO::FETCH_ASSOC);
    $get_menu->execute();

    while ($row = $get_menu->fetch()) :
        echo "
        <li>
            <div id='gambar_kategori'>
                <center>
                    <a href=''>
                        <i class='fas fa-palette'></i>
                    </a>
            </div>
            <div id='nama_kategori'>
                <h4>" . $row['kategori'] . "</h4>
                <P>2</P>
            </div>
        </li>
        ";
    endwhile;
}

function cart()
{
    include('inc/db.php');

    echo "
    <div id='wrap'>
    <div id = 'crumb'>
        <span><a href='index.php'>Home</a></span>
        <b>></b>
        <span>Keranjangku</span>
    </div>
    <div id = 'cart'>
        <table>
            <tr>
                <th id='firstColumn'>Nama</th>
                <th>Mentor</th>
                <th>Bahasa</th>
                <th>Lectures</th>
                <th>Harga</th>
            </tr>
            <tr>
                <td id='firstColumn'>
                    <img src='imgs/courses/2.jpg'/>
                    <span><a href='#'>Belajar Ethical Hacking</a></span>
                    <b><a href='#'><i class='fas fa-trash'></i>Remove</a></b>  
                </td>
                <td>Dela</td>
                <td>Indonesia</td>
                <td>20</td>
                <td  style='text-align:center'>Free</td>
            </tr>
            <tr>
                <td id='firstColumn'>
                    <img src='imgs/courses/3.jpg'/>
                    <span><a href='#'>Belajar Ethical Hacking</a></span>
                    <b><a href='#'><i class='fas fa-trash'></i>Remove</a></b>  
                </td>
                <td>Dela</td>
                <td>Indonesia</td>
                <td>20</td>
                <td  style='text-align:center'>Free</td>
            </tr>
            <tr>
                <td>
                    <button>Keep</button>
                    <button>Keep</button>
                </td>
                <td></td><td></td>
                <td style='text-align:right'>Total :</td>
                <td style='text-align:center'>Rp. 1200000</td>
            </tr>
        </table>
    </br clear='all'>
    </div>
    </div>
    ";
}

function course_detail(){
    include ("inc/db.php");
    echo "
    <div id='crumb'>
        <span><a href='index.php'>Home</a></span>
        <b>></b>
        <span>Keranjangku</span>
    </div>
    <div id='kursus_kiri'>
        <img src='imgs/courses/2.jpg'/>
    </div>
    <div id='kursus_kanan'>
        <h2>Mengenal Fotografi</h2>
        <table>
            <tr>
                <td>Mentor</td>
                <td>: Dela Faricha</td>
            </tr>
            <tr>
                <td>Mentor</td>
                <td>: Dela Faricha</td>
            </tr>
            <tr>
                <td>Mentor</td>
                <td>: Dela Faricha</td>
            </tr>
            <tr>
                <td>Mentor</td>
                <td>: Dela Faricha</td>
            </tr>
            <tr>
                <td>Mentor</td>
                <td>: Dela Faricha</td>
            </tr>
        </table>
    </div>
    <br clear='all'/>
    ";
}