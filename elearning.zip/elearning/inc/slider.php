<div id="slider">
    <img src="imgs/sliders/slide1.png" alt="">
</div>