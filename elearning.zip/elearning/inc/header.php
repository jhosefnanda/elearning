<?php
    include ("inc/function.php");
?>
<div id="header">
    <div id="up_head">
        <div id="link">
            <?php echo head_link(); ?>
        </div>
        <div id="date">
            <p><?php echo date('l, d F Y'); ?></p>
        </div>
        <div id="slog">
            <p>Sarana Alternatif Belajar Anak Indonesia</p>
        </div>
    </div>
    <div id="title">
        <h2><a href="index.php">Dolanan</a></h2>
    </div>
    <div id="menu">
        <h2><i class="far fa-caret-square-down fa-lg"></i></h2>
        <?php include("inc/cat_menu.php"); ?>
    </div>
    <div id="head_search">
        <form method="post">
            <input type="search" name="query" placeholder="Cari Kelas Belajar dan Bermain. . ">
            <button><i class="fas fa-search fa-lg"></i></button>
        </form>
    </div>
    <div id="head_cart">
        <a href="cart.php">
            <i class="fas fa-shopping-cart fa-lg"></i>
            <span>0</span>
        </a>
    </div>
    <div id="head_login">
        <h3><i class="fas fa-user-circle"></i> Login</h3>
        <form method="post">
            <center>
                <h3><i class="fas fa-user fa-lg"></i></h3>
                <h2>Login</h2>
            </center>
            <div id="input_f">
                <i class="fas fa-envelope fa-lg"></i>
                <input type="email" name="name" placeholder="Isikan Email kamu">
            </div>
            <div id="input_f">
                <i class="fas fa-lock fa-lg"></i>
                <input type="password" name="password" placeholder="Isikan password kamu">
            </div>
            <h5>Forgot Password</h5>
            <br clear="all">
            <button name="login">Login</button>
        </form>
    </div>
    <div id="head_signup">
        <h3><i class="fas fa-user-plus"></i> Daftar</h3>
        <form method="post">
            <center>
                <h3><i class="fas fa-sign-in-alt"></i></h3>
                <h2>Daftar</h2>
            </center>
            <div id="input_signup">
            <i class="fas fa-signature"></i>
                <input type="text" name="name" placeholder="Isikan Nama Lengkap kamu">
            </div>
            <div id="input_signup">
            <i class="fas fa-envelope-open-text"></i>
                <input type="email" name="password" placeholder="Isikan Email kamu">
            </div>
            <div id="input_signup">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Isikan password kamu">
            </div>
            <div id="input_signup">
            <i class="fas fa-redo-alt"></i>
                <input type="password" name="password" placeholder="Konfirmasi password kamu">
            </div>
            <br clear="all">
            <button name="daftar">Daftar</button>
        </form>
    </div>
</div>