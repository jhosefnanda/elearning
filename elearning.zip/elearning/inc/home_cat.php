<div id="home_cat">
    <h2>Kategori Kursus</h2>
    <ul>
        <?php echo categoryOnBody(); ?>
        <br clear="all">
    </ul>
</div>