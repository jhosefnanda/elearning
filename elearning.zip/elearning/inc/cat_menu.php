<ul>
    <?php echo categoryOnHeader(); ?>
</ul>