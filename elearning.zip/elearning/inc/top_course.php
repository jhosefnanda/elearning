<div id="top_course">
    <h2>Kursus Paling Diminati</h2>
    <ul>
        <li>
            <a href="../course_detail.php">
                <img src="imgs/courses/2.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/2.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/1.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/2.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/3.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/3.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
        <li>
            <a href="#">
                <img src="imgs/courses/3.jpg" alt="">
                <h3>Bagaimana sih cara kerja Robot ?</h3>
                <h4>Free</h4>
                <hr>
                <h5>Ka'Mentor : Della</h5>
            </a>
        </li>
    </ul>
</div>