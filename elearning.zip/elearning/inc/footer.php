<div id="footer">
    <ul>
        <li>
            <h2><span>Tentang</span> Dolanan.in</h2>
            <p>Dolanan.in dibuat dengan penuh kesukarelaan untuk menjadi salah satu wadah terwujudnya pendidikan alternatif</p>
            </br>
            <p>Dolanan.in dibuat dengan penuh kesukarelaan untuk menjadi salah satu wadah terwujudnya pendidikan alternatif</p>
            </br>
            <p>Dolanan.in dibuat dengan penuh kesukarelaan untuk menjadi salah satu wadah terwujudnya pendidikan alternatif</p>
        </li>
        <li>
            <h2><span>Kontak</span> Dolanan.in</h2>
            <div id="info">
                <i class="fas fa-map-marker-alt fa-lg"> Alamat</i>
                <p>Jalan Palir Raya No.66 - 68, Podorejo, Kec. Ngaliyan, Kota Semarang, Jawa Tengah 50187</p>
            </div>
            <div id="info">
                <i class="fas fa-phone-square fa-lg"> Phone</i>
                <p>0895800268976</p>
            </div>
            <div id="info">
                <i class="fas fa-envelope fa-lg">Email</i>
                <p>Jalan Palir Raya No.66 - 68, Podorejo, Kec. Ngaliyan, Kota Semarang, Jawa Tengah 50187</p>
            </div>
        </li>
        <li>
            <h2><span>Tinggalkan</span> Pesan</h2>
            <form method="post">
                <div id="form_input">
                    <i class="fas fa-user"></i>
                    <input name="name" type="text" placeholder="Nama Lengkap">
                </div>
                <div id="form_input">
                <i class="fas fa-envelope-open-text"></i>
                    <input name="email" type="email" placeholder="Email">
                </div>
                <div id="form_textarea">
                    <textarea name="msg" placeholder="Beri kami pesan disini.."></textarea>
                </div>
                <button name=""><i class="fas fa-paper-plane"></i>Kirim</button>
            </form>
        </li>
    </ul>
</div>
<div id="footer_bottom">
    <p>Developed By Jhosef Nanda 2021</p>
</div>